package com.tvparaguay.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(6,16,30), panel = Color.rgb(15,32,54), blue = Color.rgb(0,132,255), white = Color.WHITE, muted = Color.rgb(190,207,229);
    private LinearLayout root;
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(30,24,30,30); root.setBackgroundColor(bg);
        scroll.addView(root); setContentView(scroll);
        TextView logo = text("📺  TV PARAGUAY", 34, true, white); root.addView(logo);
        TextView sub = text("Canales locales • Películas • Series", 18, false, muted); root.addView(sub);
        TextView free = text("GRATIS · Acceso a plataformas y transmisiones oficiales", 16, true, Color.rgb(91,230,135)); free.setPadding(0,12,0,22); root.addView(free);
        section("🇵🇾  CANALES DE PARAGUAY");
        addButton("SNT · Sitio oficial", "https://www.snt.com.py/");
        addButton("Tre ce · Sitio oficial", "https://trece.com.py/");
        addButton("Paraguay TV · Sitio oficial", "https://www.paraguaytv.gov.py/");
        addButton("Unicanal · Sitio oficial", "https://www.unicanal.com.py/");
        addButton("ABC TV · Sitio oficial", "https://www.abctv.com.py/");
        section("🎬  PELÍCULAS Y SERIES GRATIS");
        addButton("YouTube · películas y canales oficiales", "https://www.youtube.com/");
        addButton("Plex · películas y TV gratis", "https://watch.plex.tv/");
        addButton("Pluto TV · TV y películas gratis", "https://pluto.tv/");
        addButton("Rakuten TV · sección gratuita (si está disponible)", "https://www.rakuten.tv/");
        section("📱  APLICACIONES");
        addButton("Google TV", "https://tv.google/");
        addButton("Buscar aplicaciones compatibles en Google Play", "https://play.google.com/store/apps");
        TextView note = text("Esta app reúne accesos oficiales; no aloja ni retransmite contenido. La disponibilidad depende de cada servicio y del país. Algunas plataformas pueden pedir cuenta o mostrar anuncios.", 14, false, muted);
        note.setPadding(0,22,0,10); root.addView(note);
        TextView version = text("TV Paraguay · Versión 1.0", 12, false, muted); root.addView(version);
    }
    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0,5,0,5); return t;
    }
    private void section(String s) { TextView t = text(s,22,true,white); t.setPadding(0,22,0,8); root.addView(t); }
    private void addButton(String label, String url) {
        Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setAllCaps(false); b.setTextColor(white); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel));
        b.setFocusable(true); b.setFocusableInTouchMode(true); b.setPadding(16,10,16,10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,5,0,5); root.addView(b,lp);
        b.setOnClickListener(v -> { try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); startActivity(i); } catch (Exception e) { Toast.makeText(this,"No se pudo abrir el enlace en este dispositivo.",Toast.LENGTH_LONG).show(); } });
        b.setOnFocusChangeListener((v, has) -> b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(has ? blue : panel)));
    }
}
