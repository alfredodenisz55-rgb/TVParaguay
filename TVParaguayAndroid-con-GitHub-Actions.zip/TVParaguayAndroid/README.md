# TV Paraguay — proyecto Android TV / Google TV

Primera versión: aplicación gratuita tipo lanzador que ofrece accesos a sitios oficiales de canales y plataformas de streaming gratuitas. No incluye canales pirateados, listas IPTV no autorizadas ni películas comerciales alojadas dentro de la app.

## Requisitos
- Android Studio (versión reciente)
- JDK 17
- Android SDK Platform 35 y Android Gradle Plugin descargable desde Google Maven
- Conexión a Internet durante la primera sincronización

## Generar APK
1. Descomprimir `TVParaguayAndroid.zip`.
2. Abrir Android Studio → **Open** → elegir la carpeta `TVParaguayAndroid`.
3. Aceptar la sincronización de Gradle e instalar los componentes SDK que Android Studio solicite.
4. Menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. El APK de depuración normalmente queda en `app/build/outputs/apk/debug/app-debug.apk`.

También se puede generar desde la terminal en la carpeta del proyecto con `gradlew assembleDebug` si se añade el Gradle Wrapper; en Windows se puede usar Android Studio para evitar configurar el wrapper manualmente.

## Instalar con Downloader
1. Subir el APK a un alojamiento HTTPS propio o confiable que permita descarga directa.
2. Copiar el enlace directo al archivo APK (no un enlace a una página de vista previa).
3. En el televisor, instalar/abrir Downloader e introducir el enlace.
4. Autorizar la instalación desde esa fuente cuando Android TV lo solicite, únicamente si confías en el archivo.
5. Abrir TV Paraguay desde el menú de aplicaciones.

## Publicación
Este ZIP contiene el código fuente, no un APK ya compilado ni publicado. Para distribuirlo por Downloader hace falta compilarlo y alojar el APK. No se puede añadir directamente a la lista pública de Downloader desde este proyecto.

## Canales y disponibilidad
Los botones abren sitios oficiales en el navegador o aplicación compatible. La existencia de una web no garantiza transmisión en vivo ni compatibilidad con todos los televisores. Verificar los derechos, disponibilidad geográfica y términos de cada servicio antes de publicar una versión comercial.
